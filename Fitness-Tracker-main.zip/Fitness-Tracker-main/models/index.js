module.exports = {
  Workout: require("./workoutModel"),
};
